// Referencias al DOM
const btnEditar = document.getElementById("btnEditarPerfil");
const modal = document.getElementById("editUserModal");
const form = document.getElementById("editUserForm");
const closeBtn = document.getElementById("closeUserModalButton");
const nombreEl = document.getElementById("perfil-nombre");
const usuarioEl = document.getElementById("perfil-usuario");
const rolEl = document.getElementById("perfil-rol");
const inputAvatar = document.getElementById("editUserAvatar");
const imgPerfil = document.getElementById("perfil-avatar");
const btnVolver = document.getElementById("volver");

// Inputs del modal
const inputNombre = document.getElementById("editUserName");
const inputUsername = document.getElementById("editUserUsername");
const inputClave = document.getElementById("clave");
const inputRol = document.getElementById("editUserRol");

let claveUsuarioActual = null;

// 🔄 Cargar datos del usuario logueado
function cargarUsuarioActual() {
  const usuarioActual = localStorage.getItem("usuarioActual");
  if (!usuarioActual) {
    alert("No hay sesión iniciada.");
    return;
  }

  const datos = JSON.parse(localStorage.getItem(usuarioActual));
  if (!datos) {
    alert("No se encontró el usuario actual en localStorage.");
    return;
  }

  claveUsuarioActual = usuarioActual;

  nombreEl.textContent = datos.nombre;
  usuarioEl.textContent = datos.usuario;
  rolEl.textContent = datos.rol;
  if (datos.avatar) {
    imgPerfil.src = datos.avatar;
  } else {
    imgPerfil.src = "/acess/pngwing.com.png"; // imagen por defecto si no hay avatar
  }
}


// ✏️ Abrir modal con datos
btnEditar.addEventListener("click", () => {
  if (!claveUsuarioActual) {
    alert("No hay usuario cargado.");
    return;
  }

  const datos = JSON.parse(localStorage.getItem(claveUsuarioActual));

  inputNombre.value = datos.nombre;
  inputUsername.value = datos.usuario;
  inputUsername.dataset.originalUser = claveUsuarioActual;
  inputClave.value = datos.clave || "";
  inputRol.value = datos.rol;

  modal.style.display = "flex";
});

// ❌ Cerrar modal
closeBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

// 💾 Guardar cambios
form.addEventListener("submit", (e) => {
  e.preventDefault();

  const oldKey = inputUsername.dataset.originalUser;
  const nuevoNombre = inputNombre.value.trim();
  const nuevoUsuario = inputUsername.value.trim();
  const nuevaClave = inputClave.value.trim();
  const nuevoRol = inputRol.value;
  const archivoAvatar = inputAvatar.files[0];

  if (!nuevoNombre || !nuevoUsuario || !nuevaClave) {
    alert("Completa todos los campos.");
    return;
  }

  if (oldKey !== nuevoUsuario && localStorage.getItem(nuevoUsuario)) {
    alert("Ese nombre de usuario ya existe.");
    return;
  }

  const guardarDatos = (avatarBase64) => {
    const nuevoObjeto = {
      nombre: nuevoNombre,
      usuario: nuevoUsuario,
      clave: nuevaClave,
      rol: nuevoRol,
      avatar: avatarBase64 || null
    };

    // Guardar en localStorage
    if (oldKey !== nuevoUsuario) {
      localStorage.removeItem(oldKey);
      localStorage.setItem(nuevoUsuario, JSON.stringify(nuevoObjeto));
      localStorage.setItem("usuarioActual", nuevoUsuario);
    } else {
      localStorage.setItem(nuevoUsuario, JSON.stringify(nuevoObjeto));
    }

    alert("Datos actualizados correctamente.");
    modal.style.display = "none";
    location.reload();
  };

  // Si hay una nueva imagen, convertirla a base64
  if (archivoAvatar) {
    const reader = new FileReader();
    reader.onloadend = () => {
      guardarDatos(reader.result); // Imagen en base64
    };
    reader.readAsDataURL(archivoAvatar);
  } else {
    // No se cambió la imagen, mantener la anterior
    const datosPrevios = JSON.parse(localStorage.getItem(oldKey));
    guardarDatos(datosPrevios.avatar);
  }
});

// ⏬ Ejecutar al cargar
cargarUsuarioActual();


btnVolver.addEventListener("click", () => {
  window.location.href = "/agricola/agricola.html"; // Redirigir al index del comprador
});