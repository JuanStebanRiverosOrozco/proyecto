
document.addEventListener("DOMContentLoaded", () => {
  const usuarioActual = localStorage.getItem("usuarioActual");
  const comprasRaw = localStorage.getItem("compras_agromercado");
  const compras = comprasRaw ? JSON.parse(comprasRaw) : [];

  if (!usuarioActual) {
    alert("No hay usuario activo.");
    throw new Error("Sin usuario.");
  }

  // 🔍 Filtrar ventas hechas por este usuario (como vendedor)
  const ventas = compras.filter(c => c.vendedor === usuarioActual);

  if (ventas.length === 0) {
    alert("No hay ventas registradas para este agricultor.");
    throw new Error("Sin ventas.");
  }

  // 📊 Gráfica 1: Productos vendidos
  const productosVendidos = {};
  ventas.forEach(v => {
    const titulo = v.producto?.titulo || "Producto desconocido";
    if (!productosVendidos[titulo]) productosVendidos[titulo] = 0;
    productosVendidos[titulo]++;
  });

  // 📊 Gráfica 2: Ingresos por día
  const ingresosPorDia = {};
  ventas.forEach(v => {
    const fechaCompra = v.fecha ? new Date(v.fecha) : new Date();
    const fecha = fechaCompra.toISOString().split("T")[0];
    const precio = Number(v.producto?.precio || 0);
    if (!ingresosPorDia[fecha]) ingresosPorDia[fecha] = 0;
    ingresosPorDia[fecha] += precio;
  });

  // 🟩 Crear Gráfica 1: Productos vendidos
  const ctx1 = document.getElementById("productosVendidosChart").getContext("2d");
  new Chart(ctx1, {
    type: "bar",
    data: {
      labels: Object.keys(productosVendidos),
      datasets: [{
        label: "Cantidad Vendida",
        data: Object.values(productosVendidos),
        backgroundColor: "#4CAF50"
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { precision: 0 }
        }
      }
    }
  });

  // 🔵 Crear Gráfica 2: Ingresos por día
  const ctx2 = document.getElementById("ingresosChart").getContext("2d");
  new Chart(ctx2, {
    type: "line",
    data: {
      labels: Object.keys(ingresosPorDia),
      datasets: [{
        label: "Ingresos ($)",
        data: Object.values(ingresosPorDia),
        backgroundColor: "rgba(66, 165, 245, 0.2)",
        borderColor: "#2196F3",
        fill: true,
        tension: 0.2
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
});