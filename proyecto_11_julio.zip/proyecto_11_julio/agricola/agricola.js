const perfil = document.getElementById('perfil');
perfil.addEventListener('click', () => {
    window.location.href = '/agricola/perfil/perfil.html';
});


const home = document.getElementById('home');
home.addEventListener('click', () => {
    window.location.href = '/agricola/agricola.html';
});

const estadisticas = document.getElementById('estadisticas');
estadisticas.addEventListener('click', () => {
    window.location.href = '/agricola/estadisticas/estadisticas.html';
});


// DOM Elements
const añadirBtn = document.getElementById('nuevo');
const modal = document.getElementById('añadirModal');
const closeBtn = document.getElementById('closeUserModalButton');
const form = document.getElementById('añadirProductoForm');
const productGrid = document.querySelector('.product-grid');
const headerTitle = document.querySelector("header h1");

// Detectar usuario actual
function obtenerUsuarioActual() {
    const usuario = localStorage.getItem("usuarioActual");
    if (!usuario) {
        alert("No hay un usuario actual. Usa localStorage.setItem('usuarioActual', 'nombreUsuario');");
    }
    return usuario;
}

// Mostrar nombre del usuario actual en el header
const usuarioActual = obtenerUsuarioActual();
if (usuarioActual && headerTitle) {
    headerTitle.textContent = `¡Bienvenido!, ${usuarioActual}`;
}

// Mostrar modal
añadirBtn.addEventListener('click', () => {
    modal.style.display = 'flex';
});

// Cerrar modal
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Agrega un producto al DOM
function agregarProductoAlDOM(producto) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
    <div class="image-placeholder">
      <img src="${producto.imagen}" alt="${producto.nombre}">
    </div>
    <p>${producto.nombre}</p>
    <span>$${Number(producto.precio).toLocaleString()}</span>
  `;
    productGrid.appendChild(card);
}

// Cargar productos del usuario actual
function cargarProductos() {
    const usuario = obtenerUsuarioActual();
    if (!usuario) return;

    const productosPorUsuario = JSON.parse(localStorage.getItem('productos')) || {};
    const productosDelUsuario = productosPorUsuario[usuario] || [];

    productosDelUsuario.forEach(agregarProductoAlDOM);
}

// Guardar producto al enviar el formulario
form.addEventListener('submit', (e) => {
    e.preventDefault();

    const usuario = obtenerUsuarioActual();
    if (!usuario) return;

    const nombre = document.getElementById('nameProduct').value;
    const descripcion = document.getElementById('descripcion').value;
    const precio = document.getElementById('precio').value;
    const unidades = document.getElementById('unidades').value;
    const categoria = document.getElementById('categoria').value;
    const ubicacion = document.getElementById('ubicacion').value;
    const imagen = document.getElementById('editUserAvatar').files[0];

    if (!imagen) {
        alert("Por favor selecciona una imagen.");
        return;
    }

    const reader = new FileReader();
    reader.onload = function (event) {
        const imagenURL = event.target.result;

        const producto = {
            nombre,
            descripcion,
            precio,
            unidades,
            categoria,
            ubicacion,
            imagen: imagenURL,
            id: Date.now() // Usar timestamp como ID único
        };

        // Obtener productos actuales
        let productosPorUsuario = JSON.parse(localStorage.getItem('productos')) || {};

        // Asegurar que el usuario tiene un array de productos
        if (!Array.isArray(productosPorUsuario[usuario])) {
            productosPorUsuario[usuario] = [];
        }

        // Agregar nuevo producto
        productosPorUsuario[usuario].push(producto);

        // Guardar en localStorage
        localStorage.setItem('productos', JSON.stringify(productosPorUsuario));

        // Mostrar en DOM
        agregarProductoAlDOM(producto);

        // Resetear
        form.reset();
        modal.style.display = 'none';
    };

    reader.readAsDataURL(imagen);
});

// Inicializar
window.addEventListener('DOMContentLoaded', cargarProductos);


// ==================== CLICK EN PRODUCTO PARA VER DETALLE ====================
function agregarProductoAlDOM(producto) {
  const card = document.createElement('div');
  card.className = 'product-card';
  card.style.cursor = 'pointer'; // opcional

  card.innerHTML = `
    <div class="image-placeholder">
      <img src="${producto.imagen}" alt="${producto.nombre}">
    </div>
    <p>${producto.nombre}</p>
    <span>$${Number(producto.precio).toLocaleString()}</span>
  `;

  // Manejar clic para ver detalles
  card.addEventListener('click', () => {
    localStorage.setItem("producto_seleccionado", JSON.stringify(producto));
    window.location.href = "/agricola/producto/producto.html";
  });

  productGrid.appendChild(card);
}




