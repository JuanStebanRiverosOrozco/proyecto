/* ==================== CARRITO POR USUARIO ==================== */
const getUsuarioActual = () => localStorage.getItem('usuarioActual') || 'default';

const CART_KEY = () => `carrito_${getUsuarioActual()}`;

const cargarCarrito = () => JSON.parse(localStorage.getItem(CART_KEY()) || '[]');

const guardarCarrito = (carrito) => localStorage.setItem(CART_KEY(), JSON.stringify(carrito));

const actualizarBadge = () => {
  document.getElementById('cartCount').textContent = cargarCarrito().length;
};

/* ==================== AÑADIR AL CARRITO ==================== */
document.querySelector('.product-grid').addEventListener('click', (e) => {
  if (!e.target.closest('.btn-buy')) return;
  const card = e.target.closest('.product-card');
  const { id, titulo, precio, unidad } = card.dataset;

  const carrito = cargarCarrito();

  if (carrito.some((p) => p.id === id)) {
    alert('Este producto ya está en tu carrito.');
    return;
  }

  carrito.push({ id, titulo, precio: Number(precio), unidad });
  guardarCarrito(carrito);
  actualizarBadge();
});

/* ==================== MODAL CARRITO ==================== */
const modal = document.getElementById('modalCarrito');
const abrirModal = () => { modal.classList.remove('hidden'); renderCarrito(); };
const cerrarModal = () => modal.classList.add('hidden');

document.getElementById('btnCarrito').addEventListener('click', (e) => {
  e.preventDefault();
  abrirModal();
});
document.getElementById('btnCerrarCarrito').addEventListener('click', cerrarModal);

/* ==================== RENDERIZAR TABLA CARRITO ==================== */
function renderCarrito() {
  const tbody = document.querySelector('#tablaCarrito tbody');
  tbody.innerHTML = '';
  const carrito = cargarCarrito();
  let total = 0;

  carrito.forEach((prod) => {
    total += prod.precio;
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${prod.titulo}</td>
      <td>$${prod.precio}</td>
      <td><button data-id="${prod.id}">&times;</button></td>
    `;
    tbody.appendChild(fila);
  });

  document.getElementById('totalCarrito').textContent =
    '$' + total.toLocaleString();
}

/* ==================== QUITAR PRODUCTO DEL CARRITO ==================== */
document.querySelector('#tablaCarrito tbody').addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  const id = e.target.dataset.id;
  const carrito = cargarCarrito().filter((p) => p.id !== id);
  guardarCarrito(carrito);
  renderCarrito();
  actualizarBadge();
});

document.getElementById('btnVaciar').addEventListener('click', () => {
  if (confirm('¿Vaciar todo el carrito?')) {
    guardarCarrito([]);
    renderCarrito();
    actualizarBadge();
  }
});

document.addEventListener('DOMContentLoaded', actualizarBadge);

document.getElementById('btncomprado')?.addEventListener('click', () => {
  const usuario = getUsuarioActual();
  const carrito = cargarCarrito();

  if (carrito.length === 0) {
    alert("Tu carrito está vacío.");
    return;
  }

  const comprasGuardadas = JSON.parse(localStorage.getItem('compras_agromercado') || '[]');
  const productosPorUsuario = JSON.parse(localStorage.getItem('productos') || '{}');

  carrito.forEach(producto => {
    let vendedor = "desconocido";

    // Buscar el vendedor real del producto
    for (const [usuarioVendedor, productos] of Object.entries(productosPorUsuario)) {
      if (Array.isArray(productos)) {
        const encontrado = productos.find(p => String(p.id) === String(producto.id));
        if (encontrado) {
          vendedor = usuarioVendedor;
          break;
        }
      }
    }

    comprasGuardadas.push({
      comprador: usuario,
      vendedor: vendedor,
      producto: producto,
      fecha: new Date().toISOString()
    });
  });

  localStorage.setItem('compras_agromercado', JSON.stringify(comprasGuardadas));

  // Limpiar carrito y actualizar UI
  guardarCarrito([]);
  actualizarBadge();
  renderCarrito();

  alert("¡Compra realizada y guardada exitosamente!");
});


/* ==================== AÑADIR TODOS LOS PRODUCTOS ==================== */
document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.querySelector(".product-grid");
  contenedor.innerHTML = "";

  const raw = localStorage.getItem("productos");
  if (!raw) {
    contenedor.textContent = "No hay productos guardados.";
    return;
  }

  let productosPorUsuario;
  try {
    productosPorUsuario = JSON.parse(raw);
  } catch (e) {
    console.error("Error al parsear productos:", e);
    contenedor.textContent = "Error cargando productos.";
    return;
  }

  const todosLosProductos = [];

  Object.values(productosPorUsuario).forEach(lista => {
    if (Array.isArray(lista)) {
      todosLosProductos.push(...lista);
    }
  });

  if (todosLosProductos.length === 0) {
    contenedor.textContent = "No hay productos para mostrar.";
    return;
  }

  todosLosProductos.forEach(producto => {
    const card = document.createElement("div");
    card.classList.add("product-card");

    // 🔧 Agregar datos necesarios al dataset
    card.dataset.id = producto.id;
    card.dataset.titulo = producto.nombre || "Producto sin nombre";
    card.dataset.precio = producto.precio;
    card.dataset.unidad = producto.unidades || "unidad";

    card.innerHTML = `
      <img src="${producto.imagen}" alt="${producto.nombre}">
      <div class="product-info">
        <h3>${producto.nombre || "Producto sin nombre"}</h3>
        <p class="location">
          <i class="fas fa-map-marker-alt"></i> ${producto.ubicacion || "Ubicación desconocida"}
        </p>
        <p class="price">
          $${Number(producto.precio).toLocaleString()} <span class="unit">/ ${producto.unidades || "unidad"}</span>
        </p>
        <span class="description">${producto.descripcion || "Descripción no disponible"}</span>
        <button class="btn-buy">
          <i class="fas fa-shopping-cart"></i> Añadir al Carrito
        </button>
      </div>
    `;

    contenedor.appendChild(card);
  });
});

/* ==================== FILTRO POR PRECIO ==================== */
document.addEventListener("DOMContentLoaded", () => {
  const rango = document.getElementById("precioRango");
  const texto = document.getElementById("precioTexto");
  const boton = document.querySelector(".btn-filter");
  const contenedor = document.querySelector(".product-grid");

  rango.addEventListener("input", () => {
    const valor = Number(rango.value);
    texto.textContent = `$0 - $${valor.toLocaleString()}`;
  });

  boton.addEventListener("click", () => {
    const maxPrecio = Number(rango.value);

    const raw = localStorage.getItem("productos");
    if (!raw) {
      contenedor.textContent = "No hay productos guardados.";
      return;
    }

    let productosPorUsuario;
    try {
      productosPorUsuario = JSON.parse(raw);
    } catch (e) {
      contenedor.textContent = "Error al cargar productos.";
      return;
    }

    const productosFiltrados = [];

    Object.values(productosPorUsuario).forEach(lista => {
      if (Array.isArray(lista)) {
        lista.forEach(producto => {
          if (producto.precio <= maxPrecio) {
            productosFiltrados.push(producto);
          }
        });
      }
    });

    contenedor.innerHTML = "";

    if (productosFiltrados.length === 0) {
      contenedor.textContent = "No hay productos en ese rango de precio.";
      return;
    }

    productosFiltrados.forEach(producto => {
      const card = document.createElement("div");
      card.classList.add("product-card");

      // 🔧 Agregar dataset
      card.dataset.id = producto.id;
      card.dataset.titulo = producto.nombre || "Producto sin nombre";
      card.dataset.precio = producto.precio;
      card.dataset.unidad = producto.unidades || "unidad";

      card.innerHTML = `
        <img src="${producto.imagen}" alt="${producto.nombre}">
        <div class="product-info">
          <h3>${producto.nombre || "Producto sin nombre"}</h3>
          <p class="location">
            <i class="fas fa-map-marker-alt"></i> ${producto.ubicacion || "Ubicación desconocida"}
          </p>
          <p class="price">
            $${Number(producto.precio).toLocaleString()} <span class="unit">/ ${producto.unidades || "unidad"}</span>
          </p>
          <span class="description">${producto.descripcion || "Descripción no disponible"}</span>
          <button class="btn-buy">
            <i class="fas fa-shopping-cart"></i> Añadir al Carrito
          </button>
        </div>
      `;

      contenedor.appendChild(card);
    });
  });
});

/* ==================== FILTRO POR CATEGORÍA ==================== */
document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.querySelector(".product-grid");
  const enlacesCategorias = document.querySelectorAll(".categoria-filtros a");

  function cargarProductosPorCategoria(categoriaSeleccionada) {
    const productosGuardados = localStorage.getItem("productos");

    if (!productosGuardados) {
      contenedor.innerHTML = "<p>No hay productos en localStorage.</p>";
      return;
    }

    let productosPorUsuario;
    try {
      productosPorUsuario = JSON.parse(productosGuardados);
    } catch (error) {
      contenedor.innerHTML = "<p>Error al procesar los productos.</p>";
      return;
    }

    const productosFiltrados = [];

    Object.values(productosPorUsuario).forEach(lista => {
      if (Array.isArray(lista)) {
        lista.forEach(producto => {
          if (producto.categoria === categoriaSeleccionada) {
            productosFiltrados.push(producto);
          }
        });
      }
    });

    contenedor.innerHTML = "";

    if (productosFiltrados.length === 0) {
      contenedor.innerHTML = `<p>No hay productos en la categoría "${categoriaSeleccionada}".</p>`;
      return;
    }

    productosFiltrados.forEach(producto => {
      const card = document.createElement("div");
      card.classList.add("product-card");

      // 🔧 Agregar dataset
      card.dataset.id = producto.id;
      card.dataset.titulo = producto.nombre || "Producto sin nombre";
      card.dataset.precio = producto.precio;
      card.dataset.unidad = producto.unidades || "unidad";

      card.innerHTML = `
        <img src="${producto.imagen || 'https://via.placeholder.com/250x150?text=Producto'}" alt="${producto.nombre}">
        <div class="product-info">
          <h3>${producto.nombre || "Producto sin nombre"}</h3>
          <p class="location"><i class="fas fa-map-marker-alt"></i> ${producto.ubicacion || "Ubicación desconocida"}</p>
          <p class="price">$${Number(producto.precio).toLocaleString()} <span class="unit">/ ${producto.unidades || "unidad"}</span></p>
          <span class="description">${producto.descripcion || "Descripción no disponible"}</span>
          <button class="btn-buy"><i class="fas fa-shopping-cart"></i> Añadir al Carrito</button>
        </div>
      `;

      contenedor.appendChild(card);
    });
  }

  enlacesCategorias.forEach(enlace => {
    enlace.addEventListener("click", e => {
      e.preventDefault();
      const categoria = enlace.getAttribute("data-categoria");
      cargarProductosPorCategoria(categoria);
    });
  });
});
  
document.addEventListener("DOMContentLoaded", () => {
  const inputBusqueda = document.getElementById("searchInput");
  const contenedor = document.querySelector(".product-grid");

  inputBusqueda.addEventListener("input", () => {
    const termino = inputBusqueda.value.toLowerCase().trim();
    const cards = contenedor.querySelectorAll(".product-card");

    cards.forEach(card => {
      const titulo = (card.dataset.titulo || "").toLowerCase();
      const descripcion = (card.querySelector(".description")?.textContent || "").toLowerCase();
      const visible = titulo.includes(termino) || descripcion.includes(termino);
      card.style.display = visible ? "block" : "none";
    });
  });
});

// ==================== CLICK EN PRODUCTO PARA VER DETALLE ====================
document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.querySelector(".product-grid");

  contenedor.addEventListener("click", (e) => {
    const card = e.target.closest(".product-card");
    if (!card) return;

    // Evita que el botón de "Añadir al carrito" active este evento
    if (e.target.closest(".btn-buy")) return;

    const producto = {
      id: card.dataset.id,
      titulo: card.dataset.titulo,
      precio: card.dataset.precio,
      unidad: card.dataset.unidad,
      imagen: card.querySelector("img")?.src || '',
      descripcion: card.querySelector(".description")?.textContent || ''
    };

    // Guarda el producto clicado y redirige
    localStorage.setItem("producto_seleccionado", JSON.stringify(producto));
    window.location.href = "/comprador/producto/producto.html";
  });
});
