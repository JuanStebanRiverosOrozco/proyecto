// ─── Referencias al DOM ─────────────────────────────────────────────────────────
const tablaBody   = document.querySelector('#tablaUsuarios tbody');
const modal       = document.getElementById('editUserModal');
const form        = document.getElementById('editUserForm');
const closeBtn    = document.getElementById('closeUserModalButton');

// ─── Cargar usuarios en la tabla ───────────────────────────────────────────────
for (let i = 0; i < localStorage.length; i++) {
  const clave = localStorage.key(i);
  try {
    const datos = JSON.parse(localStorage.getItem(clave));
    if (datos?.nombre && datos?.clave && datos?.rol) {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td>${datos.nombre}</td>
        <td>${clave}</td>
        <td>${datos.rol}</td>
        <td>
          <button class="editar"   data-user="${clave}">Editar</button>
          <button class="eliminar" data-user="${clave}">Eliminar</button>
        </td>`;
      tablaBody.appendChild(fila);
    }
  } catch {
    // ignorar valores no válidos
  }
}

// ─── Delegación de clics en la tabla ───────────────────────────────────────────
tablaBody.addEventListener('click', (e) => {
  const usuario = e.target.dataset.user;
  if (!usuario) return;

  if (e.target.classList.contains('eliminar')) {
    if (confirm(`¿Eliminar al usuario "${usuario}"?`)) {
      localStorage.removeItem(usuario);
      location.reload();
    }
  }

  if (e.target.classList.contains('editar')) {
    abrirModalEdicion(usuario);
  }
});

// ─── Abrir modal con datos ─────────────────────────────────────────────────────
function abrirModalEdicion(usuario) {
  const datos = JSON.parse(localStorage.getItem(usuario));

  if (!datos) {
    alert('Usuario no encontrado.');
    return;
  }

  const inputUsername = document.getElementById('editUserUsername');
  inputUsername.value = usuario;
  inputUsername.dataset.originalUser = usuario;

  document.getElementById('editUserName').value = datos.nombre;
  document.getElementById('editUserRol').value = datos.rol;
  document.getElementById('clave').value = datos.clave; 

  modal.classList.add('show');
}

// ─── Cerrar modal ──────────────────────────────────────────────────────────────
closeBtn.addEventListener('click', () => {
  modal.classList.remove('show');
});

// ─── Guardar cambios ───────────────────────────────────────────────────────────
form.addEventListener('submit', (e) => {
  e.preventDefault();

  const oldUsername   = form.editUserUsername.dataset.originalUser;
  const newUsername   = form.editUserUsername.value.trim();
  const nuevoNombre   = form.editUserName.value.trim();
  const nuevoRol      = form.editUserRol.value;
  const clave         = form.clave.value.trim();

  if (!nuevoNombre || !newUsername || !nuevoRol) {
    alert('Completa todos los campos.');
    return;
  }

  // Validar si cambió el nombre de usuario y ya existe uno igual
  if (oldUsername !== newUsername && localStorage.getItem(newUsername)) {
    alert('Ese nombre de usuario ya existe.');
    return;
  }

  const nuevoUsuario = {
    nombre: nuevoNombre,
    usuario: newUsername,
    clave: clave,
    rol: nuevoRol
    
  };

  if (oldUsername !== newUsername) {
    localStorage.removeItem(oldUsername);
  }

  localStorage.setItem(newUsername, JSON.stringify(nuevoUsuario));

  alert('Usuario actualizado correctamente.');
  modal.classList.remove('show');
  location.reload();
});
